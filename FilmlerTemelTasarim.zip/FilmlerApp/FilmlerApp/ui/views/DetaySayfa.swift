//
//  DetaySayfa.swift
//  FilmlerApp
//
//  Created by Macbook on 01/03/2024.
//

import UIKit

class DetaySayfa: UIViewController {

    @IBOutlet weak var labelFilm: UILabel!
    
    @IBOutlet weak var imageViewFilm: UIImageView!
   
    @IBOutlet weak var labelFiyat: UILabel!
    
    //bu alana film nesnesi ile ilgili bilgi gelsin istiyorum.
    
    var film:Filmler?
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        if let f = film {
            labelFilm.text = f.ad
            imageViewFilm.image = UIImage(named: f.resim!)
            labelFiyat.text = "\(f.fiyat!) ₺"
        }
      

    }
     //bu sayfada dışarıdan gelen nesneleri aldım ve gösterdim. 


}
