//
//  FilmlerHucre.swift
//  FilmlerApp
//
//  Created by Macbook on 01/03/2024.
//

import UIKit
protocol HucreProtokol {
    func sepeteEkleTikla(indexPath:IndexPath) //şimdi bunu nerede kullanıcaksam oraya eklemem gerekiyor. 
}
class FilmlerHucre: UICollectionViewCell {
    @IBOutlet weak var imageViewFilm: UIImageView!
    
    @IBOutlet weak var labelFiyat: UILabel!
    
    var hucreProtocol:HucreProtokol?
    var indexPath:IndexPath?
    @IBAction func buttonSepeteEkle(_ sender: Any) {
        //burada hangi film nesnesine eriştiğimi anlamam gerek. Ama şu an ki hali ile bunu anlamam mümkün değil. Ben bunun için ana sayfada çalışmak istiyorum. Bunun için tetikleyen hucre class ı anasayfa da çalıştıran kısım olucak.Yine protokol oluşturucam
        hucreProtocol?.sepeteEkleTikla(indexPath: indexPath! ) 
    }
    
    
    
}
